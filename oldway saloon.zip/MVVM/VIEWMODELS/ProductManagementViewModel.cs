using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using POS_OLDWAY_SALOON.MVVM.MODELS;
using POS_OLDWAY_SALOON.MVVM.VIEWS;
using POS_OLDWAY_SALOON.Services;
using System.Collections.ObjectModel;

namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS;

public partial class ProductManagementViewModel : ObservableObject
{
    private readonly APISERVICES _api = new APISERVICES();

    [ObservableProperty] private int categoryId;
    [ObservableProperty] private string categoryName = string.Empty;

    [ObservableProperty] private string searchText = string.Empty;

    public ObservableCollection<Product> FilteredProducts { get; } = new();

    public ProductManagementViewModel()
    {
        // Initial load will be done via SetCategory
    }

    public async void SetCategory(Category category)
    {
        CategoryId = category.CategoryId;
        CategoryName = category.CategoryName;

        var products = await _api.GetProductsByCategoryAsync(category.CategoryId);
        FilteredProducts.Clear();
        foreach (var p in products)
            FilteredProducts.Add(p);
    }

    partial void OnSearchTextChanged(string value)
    {
        // Simple client-side filter
        var filtered = string.IsNullOrWhiteSpace(value)
            ? FilteredProducts.ToList()
            : FilteredProducts.Where(p => p.ProductName.Contains(value, StringComparison.OrdinalIgnoreCase)).ToList();

        FilteredProducts.Clear();
        foreach (var p in filtered)
            FilteredProducts.Add(p);
    }

    [RelayCommand]
    private async Task AddProduct()
    {
        var page = AppPages.NewAddProductView();
        page.OnProductSaved = async (product) =>
        {
            product.CategoryId = CategoryId;   // important
            bool success = await _api.AddProductAsync(product);
            if (success)
                await LoadProducts();
        };
        await PushAsync(page);
    }

    [RelayCommand]
    private async Task EditProduct(Product product)
    {
        var page = AppPages.NewAddProductView();
        page.LoadProduct(product);
        page.OnProductSaved = async (updated) =>
        {
            bool success = await _api.UpdateProductAsync(updated);  // you'll need to add UpdateProductAsync to APISERVICES if not already
            if (success)
                await LoadProducts();
        };
        await PushAsync(page);
    }

    [RelayCommand]
    private async Task DeleteProduct(Product product)
    {
        bool confirm = await Application.Current!.MainPage!.DisplayAlert("Delete", $"Delete {product.ProductName}?", "Yes", "No");
        if (!confirm) return;

        bool success = await _api.DeleteProduct(product.ProductId);   // you'll need DeleteProduct in APISERVICES
        if (success)
            await LoadProducts();
    }

    private async Task LoadProducts()
    {
        var products = await _api.GetProductsByCategoryAsync(CategoryId);
        FilteredProducts.Clear();
        foreach (var p in products)
            FilteredProducts.Add(p);
    }

    private static async Task PushAsync(Page page)
    {
        if (Application.Current?.MainPage is FlyoutPage flyout && flyout.Detail is NavigationPage nav)
            await nav.PushAsync(page);
    }

    [RelayCommand]
    private async Task GoBack()
    {
        if (Application.Current?.MainPage is FlyoutPage flyout && flyout.Detail is NavigationPage nav)
            await nav.PopAsync();
    }
}