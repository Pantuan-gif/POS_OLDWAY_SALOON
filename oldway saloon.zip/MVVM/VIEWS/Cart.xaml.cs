namespace POS_OLDWAY_SALOON.MVVM.VIEWS;
namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS
public partial class Cart : ContentPage
{
	public Cart()
	{
		InitializeComponent();
		BindingContext = new CartViewModel();
	}
}