namespace POS_OLDWAY_SALOON.MVVM.VIEWS;
namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS;

public partial class Home : ContentPage
{
    public int thisId { get; set; }
    public Home()
	{
		InitializeComponent();
        BindingContext = new HomeViewModel(); 
    }
	}

}