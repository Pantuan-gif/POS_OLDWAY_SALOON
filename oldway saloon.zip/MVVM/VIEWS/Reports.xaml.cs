namespace POS_OLDWAY_SALOON.MVVM.VIEWS;
namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS;

public partial class Reports : ContentPage
{
	public Reports()
	{
		InitializeComponent();
		BindingContext = new ReportsViewModel();
	}
}