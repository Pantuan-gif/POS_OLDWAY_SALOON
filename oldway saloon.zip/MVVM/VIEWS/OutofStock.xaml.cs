namespace POS_OLDWAY_SALOON.MVVM.VIEWS;
namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS;

public partial class OutofStock : ContentPage
{
	public OutofStock()
	{
		InitializeComponent();
		BindingContext = new OutofStockViewModel();
	}
}