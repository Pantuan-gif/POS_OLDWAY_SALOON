namespace POS_OLDWAY_SALOON.MVVM.VIEWS;
namepsace POS_OLDWAY_SALOON.MVVM.VIEWMODELS;
public partial class OrderingManagement : ContentPage
{
	public OrderingManagement()
	{
		InitializeComponent();
		BindingContext = new OrderingManagementViewModel();
	}
}