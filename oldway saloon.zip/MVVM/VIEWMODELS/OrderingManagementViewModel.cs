using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using POS_OLDWAY_SALOON.MVVM.MODELS;
using POS_OLDWAY_SALOON.MVVM.SERVICES;
using POS_OLDWAY_SALOON.Services;
using System.Collections.ObjectModel;

namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS;

public partial class OrderingManagementViewModel : ObservableObject
{
    private readonly APISERVICES _api = new APISERVICES();

    [ObservableProperty] private string searchText = string.Empty;

    public ObservableCollection<Product> FilteredProducts { get; } = new();

    public OrderingManagementViewModel()
    {
        LoadAllProducts();
    }

    private async void LoadAllProducts()
    {
        // For simplicity we load all products (you can improve with category filter later)
        var response = await _api.GetAllProductsAsync();   // Add this method to APISERVICES if needed
        FilteredProducts.Clear();
        foreach (var product in response)
            FilteredProducts.Add(product);
    }

    partial void OnSearchTextChanged(string value)
    {
        var filtered = string.IsNullOrWhiteSpace(value)
            ? FilteredProducts.ToList()
            : FilteredProducts.Where(p => p.ProductName.Contains(value, StringComparison.OrdinalIgnoreCase)).ToList();

        FilteredProducts.Clear();
        foreach (var p in filtered)
            FilteredProducts.Add(p);
    }

    [RelayCommand]
    private void AddToCart(Product product)
    {
        if (product.Quantity <= 0)
        {
            Application.Current?.MainPage?.DisplayAlert("Out of Stock", $"{product.ProductName} is out of stock", "OK");
            return;
        }

        CartService.AddToCart(product);
        Application.Current?.MainPage?.DisplayAlert("Added", $"{product.ProductName} added to cart", "OK");
    }

    // Helper method - add this to APISERVICES.cs if missing
    // public async Task<List<Product>> GetAllProductsAsync()
    // {
    //     var response = await _client.GetAsync("products");
    //     return response.IsSuccessStatusCode 
    //         ? await response.Content.ReadFromJsonAsync<List<Product>>() ?? new()
    //         : new();
    // }
}