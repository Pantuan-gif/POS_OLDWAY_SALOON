namespace POS_OLDWAY_SALOON.MVVM.VIEWS;
namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS

public partial class Payment : ContentPage
{
	public Payment()
	{
		InitializeComponent();
		BindingContext = new PaymentViewModel();
	}
}