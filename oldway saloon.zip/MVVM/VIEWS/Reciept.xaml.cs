namespace POS_OLDWAY_SALOON.MVVM.VIEWS;
namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS;

public partial class Reciept : ContentPage
{
	public Reciept()
	{
		InitializeComponent();
		BindingContext = new RecieptViewModel();
	}
}