namespace POS_OLDWAY_SALOON.MVVM.VIEWS;
namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS;

public partial class TransactionReports : ContentPage
{
	public TransactionReports()
	{
		InitializeComponent();
		BindingContext = new ReportsViewModel();
	}
}