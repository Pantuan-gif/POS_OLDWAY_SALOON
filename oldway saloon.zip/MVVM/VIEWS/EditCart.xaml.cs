namespace POS_OLDWAY_SALOON.MVVM.VIEWS;
namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS

public partial class EditCart : ContentPage
{
	public EditCart()
	{
		InitializeComponent();
		BindingContext = new EditCartViewModel();
	}
}