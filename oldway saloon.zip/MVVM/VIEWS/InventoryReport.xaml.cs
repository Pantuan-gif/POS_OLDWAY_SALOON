namespace POS_OLDWAY_SALOON.MVVM.VIEWS;
namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS;

public partial class InventoryReport : ContentPage
{
	public InventoryReport()
	{
		InitializeComponent();
		BindingContext = new InventoryReportViewModel();
	}
}