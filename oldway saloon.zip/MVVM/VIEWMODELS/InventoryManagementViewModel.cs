using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using POS_OLDWAY_SALOON.MVVM.MODELS;
using POS_OLDWAY_SALOON.MVVM.VIEWS;
using POS_OLDWAY_SALOON.Services;
using System.Collections.ObjectModel;

namespace POS_OLDWAY_SALOON.MVVM.VIEWMODELS;

public partial class InventoryManagementViewModel : ObservableObject
{
    private readonly APISERVICES _api = new APISERVICES();

    [ObservableProperty]
    private string searchText = string.Empty;

    public ObservableCollection<Category> FilteredCategories { get; } = new();

    public InventoryManagementViewModel()
    {
        LoadCategories();
    }

    private async void LoadCategories()
    {
        var categories = await _api.GetAllCategoriesAsync();
        FilteredCategories.Clear();
        foreach (var cat in categories)
            FilteredCategories.Add(cat);
    }

    partial void OnSearchTextChanged(string value)
    {
        // Simple client-side filter for now
        var filtered = string.IsNullOrWhiteSpace(value)
            ? FilteredCategories.ToList()
            : FilteredCategories.Where(c => c.CategoryName.Contains(value, StringComparison.OrdinalIgnoreCase)).ToList();

        FilteredCategories.Clear();
        foreach (var cat in filtered)
            FilteredCategories.Add(cat);
    }

    [RelayCommand]
    private async Task AddCategory()
    {
        var page = AppPages.NewAddCategoryView();
        page.OnCategoryAdded = async (category) =>
        {
            bool success = await _api.AddCategoryAsync(category);
            if (success)
                LoadCategories();
        };
        await PushAsync(page);
    }

    [RelayCommand]
    private async Task ManageCategory(Category category)
    {
        var page = AppPages.NewProductManagementView();
        page.SetCategory(category);
        await PushAsync(page);
    }

    private static async Task PushAsync(Page page)
    {
        if (Application.Current?.MainPage is FlyoutPage flyout && flyout.Detail is NavigationPage nav)
            await nav.PushAsync(page);
    }
}